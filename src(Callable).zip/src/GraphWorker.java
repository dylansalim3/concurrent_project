import java.util.concurrent.Callable;

public class GraphWorker implements Callable<Line>{
	private Graph graph;
	private int attempt = 0;


	public GraphWorker(Graph graph) {
		this.graph = graph;
	}
	
	@Override
	public Line call() throws Exception{
		Line l;
		do {
			l = graph.drawLine();
			attempt++;
		}while(l==null && attempt<20);
		
		if(l != null) {
			return l;
		}else {
			return null;
		}
	}
}
