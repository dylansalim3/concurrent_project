import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class Main {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
		int m= 1;
		int n = 10000;
		int t = 4;
		
		Graph graph = new Graph();
		GraphWorker[] graphWorkers = new GraphWorker[n];
		ExecutorService executorService = Executors.newFixedThreadPool(t);
		List<Future> lineFutures = new ArrayList<>();
		List<Line> lineList = new ArrayList<>();
		
		for(int i=0; i<n; i++) 
		{
			GraphWorker graphWorker = new GraphWorker(graph);
			graphWorkers[i] = graphWorker;
			Future lineFuture = executorService.submit(graphWorker);
			lineFutures.add(lineFuture);
		}
		
		try 
		{
			if(!executorService.awaitTermination(m, TimeUnit.MILLISECONDS))
			{
				executorService.shutdown();
				if(!executorService.isTerminated()) 
				{
					executorService.shutdownNow();
				}
				System.out.println("Thread Terminated");
			}
		}
		catch(InterruptedException e) 
		{
			executorService.shutdownNow();
		}
		
		try 
		{
		for(int i=0; i<lineFutures.size();i++)
		{
			Future future = lineFutures.get(i);
			if(executorService.isTerminated()&&!future.isDone())
			{
				lineFutures.get(i).cancel(true);
			}
			else 
			{
				lineList.add((Line) future.get());
			}
		}
		}
		catch(InterruptedException e)
		{
			System.out.println("Interruption Occur.");
			e.printStackTrace();
		}
		
		printDetails(lineList);
		executorService.shutdown();
		
	}
	
	  public static void printDetails(List<Line> lineList) {
	        System.out.println("Total lines created :" + lineList.size());
	        System.out.println("Created lines list :" + lineList.toString());
	    }

}
